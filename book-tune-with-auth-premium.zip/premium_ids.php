<?php
// Server-side source of truth for which books are premium-only
$PREMIUM_BOOK_IDS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];
?>